from django.shortcuts import render
from .models import Device, Heartbeat, User

def device_list(request):
    # Get devices for the logged-in user
    devices = Device.objects.filter(user=request.user) if request.user.is_authenticated else []

    return render(request, 'device_list.html', {
        'devices': devices,
        'user_context': request.user_context,  # Pass user context if needed
    })

def user_list(request):
    users = User.objects.all()  # Get all users
    return render(request, 'user_list.html', {'users': users})

def user_devices(request, user_id):
    devices = Device.objects.filter(user_id=user_id)  # Get devices for the specified user
    return render(request, 'user_devices.html', {'devices': devices})

import paho.mqtt.client as mqtt
from django.core.management.base import BaseCommand
from django.utils.timezone import now
from myapp.models import Device, Heartbeat

class Command(BaseCommand):
    help = 'Starts the MQTT listener to receive device data'

    def handle(self, *args, **kwargs):
        def on_message(client, userdata, message):
            try:
                payload = message.payload.decode("utf-8")
                topic = message.topic

                if topic == 'device/status':
                    device_id, state = payload.split(',')
                    device = Device.objects.get(id=device_id)
                    device.machine_state = state
                    device.save()
                    print(f"Updated device {device.device_name} to state {state}")

                elif topic == 'device/heartbeat':
                    device_id, heart_rate = payload.split(',')
                    device = Device.objects.get(id=device_id)
                    Heartbeat.objects.create(device=device, heart_rate=int(heart_rate), last_heartbeat=now())
                    print(f"Recorded heartbeat for {device.device_name}: {heart_rate} bpm")

            except Device.DoesNotExist:
                print(f"Device with ID {device_id} does not exist.")
            except ValueError:
                print(f"Invalid payload format: {payload} on topic {topic}")
            except Exception as e:
                print(f"Error handling message: {e}")

        client = mqtt.Client()
        client.on_message = on_message
        client.connect('localhost', 1883)  # Replace with your broker address if needed
        client.subscribe('device/heartbeat')
        client.subscribe('device/status')

        print("MQTT listener started, waiting for messages...")
        client.loop_forever()  # Keeps the listener running

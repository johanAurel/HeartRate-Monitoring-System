from django.db import models
from django.db import connection
from django.utils import timezone
import paho.mqtt.client as mqtt
from werkzeug.security import check_password_hash


class User(models.Model):
    username = models.CharField(max_length=128, unique=True)
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.username
     
class Device(models.Model):
    machine_states = [('ON','ON'), ('OFF','OFF')]
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    device_name = models.CharField(max_length=128)   
    machine_state = models.CharField(max_length=3, choices=machine_states, default='OFF')

    def __str__(self):
        return f"{self.device_name} ({self.user.username})"

class Heartbeat(models.Model):

    device = models.ForeignKey(Device, on_delete=models.CASCADE)
    last_heartbeat = models.DateTimeField(null=True)
    heart_rate = models.IntegerField(null=True)

    def save(self, *args, **kwargs):
        if not self.id:
            self.last_heartbeat = timezone.now()
        super().save(*args, **kwargs)
    
    def is_abnormal_high(self):
        if self.heart_rate > 100:
              # Sending a message to the IoT machine
            mqtt_client = mqtt.Client()
            mqtt_client.connect("your_broker_address", 1883, 60)  # Replace with MQTT broker details

            # Create a message to send
            message = f"ALERT: Abnormal heart rate detected ({self.heart_rate}) for device: {self.device.device_name}"

            # Publish the message to a specific topic
            mqtt_client.publish("iot/device/alerts", message)  # Replace with topic

            # Disconnect after sending the message
            mqtt_client.disconnect()

            print(f"Message sent: {message}")
            
    def __str__(self):
        return f"{self.device.device_name} - {self.heart_rate} bpm at {self.last_heartbeat}"
    
def connect(username=input('username or email')):
    users = User.objects.username
    emails = User.objects.email
    with connection.cursor() as cursor:
    
     if username in users or username in emails:
        User.objects.get(username=username, email=emails[username])
        if User.email == None:
            email =input('email must be provided')
            User.objects.filter(username=username).update(email=email)
            password = input('password')
            if password == cursor.execute("SELECT password_hash FROM users WHERE username = %s", (username,)):
                print('Logged in successfully')
                return cursor.execute(f'USE {username}')
        elif User.username == None:
            username = input('username must be provided')
            User.objects.filter(email=emails[username]).update(username=username)
            password = input('password')
            if password == cursor.execute("SELECT password_hash FROM users WHERE username = %s", (username,)):
                print('Logged in successfully')
                return cursor.execute(f'USE {username}')
            else:
                print("Incorrect password")
                return connect(username)
        else:
            print('Logged in successfully')
            return cursor.execute(f'USE {username}')    

        return users[users.index(username)].id
     else:
        password = input("Password") #write it somewhere to not forget 
        commands =[f"CREATE USER {username}@'localhost' IDENTIFIED BY {password};",f"GRANT SELECT, INSERT, UPDATE, DELETE ON heart_rate_db.[table for table in heart_rate_db if {username} in table.username or {username} in table.user.username] TO '{username}'@'localhost';","USE {username};"]
        
   



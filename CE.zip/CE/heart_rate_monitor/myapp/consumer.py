import json
from channels.generic.websocket import AsyncWebsocketConsumer

class DeviceConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()

    async def disconnect(self, close_code):
        pass

    async def receive(self, text_data):
        data = json.loads(text_data)
        device_id = data['device_id']

        # You can add logic here to get real-time data from the database or MQTT client
        await self.send(text_data=json.dumps({
            'device_id': device_id,
            'heart_rate': 75,  # Replace with actual heart rate from the database or MQTT message
            'machine_state': 'ON'  # Replace with actual machine state
        }))

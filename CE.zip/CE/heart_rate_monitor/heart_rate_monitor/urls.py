from django.urls import path
from .views import device_list, user_list, user_devices

urlpatterns = [
    path('devices/', device_list, name='device_list'),#URL for viewing list of devices
    path('users/', user_list, name='user_list'),  # URL for viewing all users
    path('users/<int:user_id>/devices/', user_devices, name='user_devices'),  # URL for viewing a specific user's devices
]   
